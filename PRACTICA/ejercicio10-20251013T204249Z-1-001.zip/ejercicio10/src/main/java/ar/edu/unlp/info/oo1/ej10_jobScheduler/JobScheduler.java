package ar.edu.unlp.info.oo1.ej10_jobScheduler;

import java.util.ArrayList;
import java.util.List;

public class JobScheduler {
    protected List<JobDescription> jobs;
    protected Strategy strategy;

    public JobScheduler () {
        this.jobs = new ArrayList<>();
        this.strategy = new FIFOStrategy();  // Estartegia por defecto
    }

    public void schedule(JobDescription job) {
        this.jobs.add(job);
    }

    public void unschedule(JobDescription job) {
            this.jobs.remove(job);

    }
    public void setStrategy(Strategy strategy){
        this.strategy=strategy;
    }

    public Strategy getStrategy() {
        return this.strategy; 
    }

    public List<JobDescription> getJobs(){
        return jobs;
    }

    public JobDescription next() {
        if (this.jobs.isEmpty()) return null;

        JobDescription nextJob=this.strategy.next(this.jobs);
        this.unschedule(nextJob);
        return nextJob;
    }

}
