package ar.edu.unlp.info.oo1.ej10_jobScheduler;
import java.util.List;

public class FIFOStrategy implements Strategy {
    public JobDescription next(List<JobDescription> jobs){
        if (jobs.isEmpty()) return null;
        return jobs.get(0);
    }
}
