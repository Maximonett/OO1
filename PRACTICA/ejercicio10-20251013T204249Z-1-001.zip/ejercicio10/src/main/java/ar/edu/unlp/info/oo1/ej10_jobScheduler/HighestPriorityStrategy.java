package ar.edu.unlp.info.oo1.ej10_jobScheduler;

import java.util.List;

public class HighestPriorityStrategy implements Strategy{
    public JobDescription next(List<JobDescription> jobs){
        if (jobs.isEmpty()) return null;
        return jobs.stream()
            .max((j1,j2) -> Integer.compare(j1.getPriority(), j2.getPriority()))
            .orElse(null);
    }

}
